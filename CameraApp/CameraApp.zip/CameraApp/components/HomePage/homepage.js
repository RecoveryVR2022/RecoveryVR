import React from 'react';

export default function Homepage() {
  return(
    <h2>Homepage</h2>
  );
}